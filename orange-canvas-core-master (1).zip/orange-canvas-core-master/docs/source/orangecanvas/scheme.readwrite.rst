.. schemereadwrite:

====================================
Scheme Serialization (``readwrite``)
====================================


.. automodule:: orangecanvas.scheme.readwrite
   :members:
