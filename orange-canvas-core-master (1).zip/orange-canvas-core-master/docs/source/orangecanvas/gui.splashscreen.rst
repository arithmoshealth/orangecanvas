================================
Splash Screen (``splashscreen``)
================================

.. automodule:: orangecanvas.gui.splashscreen

.. autoclass:: orangecanvas.gui.splashscreen.SplashScreen
   :members:
   :member-order: bysource
   :show-inheritance:
