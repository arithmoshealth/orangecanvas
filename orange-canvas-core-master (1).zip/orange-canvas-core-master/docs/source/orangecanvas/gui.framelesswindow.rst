=============================================
Frameless Window Widget (``framelesswindow``)
=============================================

.. automodule:: orangecanvas.gui.framelesswindow

.. autoclass:: orangecanvas.gui.framelesswindow.FramelessWindow
   :members:
   :member-order: bysource
   :show-inheritance:
