==================================
Collapsible Dock Widget (``dock``)
==================================

.. automodule:: orangecanvas.gui.dock

.. autoclass:: orangecanvas.gui.dock.CollapsibleDockWidget
   :members:
   :member-order: bysource
   :show-inheritance:
   :exclude-members:
       setWidget, animationEnabled, setAnimationEnabled
