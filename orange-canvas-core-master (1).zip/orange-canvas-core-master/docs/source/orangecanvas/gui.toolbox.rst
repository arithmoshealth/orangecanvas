=============================
Tool Box Widget (``toolbox``)
=============================

.. automodule:: orangecanvas.gui.toolbox

.. autoclass:: orangecanvas.gui.toolbox.ToolBox
   :members:
   :member-order: bysource
   :show-inheritance:

   .. autoattribute:: tabToggled(index: int, state: bool)

      Signal emitted when a tab at `index` is toggled.
