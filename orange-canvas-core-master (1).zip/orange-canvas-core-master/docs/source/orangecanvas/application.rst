.. application:

#############################
Application (``application``)
#############################

.. automodule:: orangecanvas.application

.. toctree::
   :maxdepth: 1

   application.welcomedialog
   application.canvasmain
