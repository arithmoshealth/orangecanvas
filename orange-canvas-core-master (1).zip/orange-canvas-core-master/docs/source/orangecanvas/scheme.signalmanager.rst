.. signalmanager:

.. automodule:: orangecanvas.scheme.signalmanager

.. autoclass:: SignalManager
   :members:
   :member-order: bysource
   :show-inheritance:

.. autoclass:: Signal
   :members:
