==================================
Drop Shadow Frame (``dropshadow``)
==================================

.. automodule:: orangecanvas.gui.dropshadow

.. autoclass:: orangecanvas.gui.dropshadow.DropShadowFrame
   :members:
   :member-order: bysource
   :show-inheritance:
