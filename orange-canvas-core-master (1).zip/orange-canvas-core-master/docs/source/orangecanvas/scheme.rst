.. scheme:

###################
Scheme (``scheme``)
###################


.. automodule:: orangecanvas.scheme


.. toctree::

   scheme.scheme
   scheme.node
   scheme.link
   scheme.annotation
   scheme.readwrite
   scheme.widgetmanager
   scheme.signalmanager
   scheme.events
