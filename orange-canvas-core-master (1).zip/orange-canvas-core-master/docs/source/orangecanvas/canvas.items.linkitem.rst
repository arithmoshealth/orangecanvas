.. canvas-link-item:

========================
Link Item (``linkitem``)
========================

.. automodule:: orangecanvas.canvas.items.linkitem


.. autoclass:: LinkItem
   :members:
   :member-order: bysource
   :show-inheritance:
