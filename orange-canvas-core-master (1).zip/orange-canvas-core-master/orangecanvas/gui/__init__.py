"""
===========
GUI toolkit
===========

A GUI toolkit with widgets used by other parts of Orange Canvas.

Extends basic Qt classes with extra functionality.

"""
